import pandas as pd
data=pd.read_excel('最大心率统计表.xlsx')

num = int(input("你平常的脉搏数是多少？ヽ(°◇° )ノ "))

print("你希望你的最大脉搏数是：ー(￣～￣)ξ ")
print("(1)220-年龄    (2)185")
flag = int(input("请做选择（输入1或2）： "))
max = 0
if flag == 1:
    age = int(input("请输入你的年龄：φ(≧ω≦*)♪ ")) 
    max = 220 - age
if flag == 2:
    max = 185

import random
import numpy as np

for i in range(2,9):
    j = 1
    while j<13:
        pengpong = random.randint(num-10,num+10)
        data.iloc[i,j] = pengpong
        radio = (pengpong/max)*100
        radio = round(radio,1)
        
        data.iloc[i,j+1] = str(radio) + '%'
        j += 2
    

data.to_excel('哈哈哈你滴脉搏数据.xlsx',encoding='GB2312')

print("打开程序解压目录看看有没有成功，生成的是excel文件，把数据复制到你的表格即可ヾ(￣▽￣)Bye~Bye~")
